# include <iostream>

void start()//�����ͷ����
{
	std::cout << "========================================" << std::endl;
	std::cout << "Unit Converter v1.0 for English By WYC-M" << std::endl;
	std::cout << "========================================" << std::endl;

	std::cout << std::endl;
	std::cout << std::endl;
}