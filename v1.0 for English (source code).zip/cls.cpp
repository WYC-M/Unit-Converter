# include <stdlib.h>
# include "header.h"

void cls()//����
{
	system("cls");
	start();
}